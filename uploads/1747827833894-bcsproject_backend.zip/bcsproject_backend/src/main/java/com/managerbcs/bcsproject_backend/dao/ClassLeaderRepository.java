package com.managerbcs.bcsproject_backend.dao;

import com.managerbcs.bcsproject_backend.entity.ClassLeader;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClassLeaderRepository extends JpaRepository<ClassLeader, Integer> {
}
