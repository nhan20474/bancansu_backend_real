package com.managerbcs.bcsproject_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BcsprojectBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
